from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),  # Ruta para la página principal
    path('contacto/', views.contacto_view, name='contacto'),
    path('acerca_de/', views.acerca_de, name='acerca_de'),
    path('register/',views.registro, name = 'registro'),
]
