from django.db import models
from productos.models import Producto  # Ajusta la importación según tu estructura
from django.contrib.auth import get_user_model

User = get_user_model()

class Transaccion(models.Model):
    producto = models.ForeignKey(
        Producto,
        on_delete=models.CASCADE,
        related_name="transacciones_producto"  # Nombre único para esta relación inversa
    )
    comprador = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name="transacciones_como_comprador"  # Nombre único para el comprador
    )
    vendedor = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name="transacciones_como_vendedor"  # Nombre único para el vendedor
    )
    precio = models.DecimalField(max_digits=10, decimal_places=2)
    fecha = models.DateTimeField(auto_now_add=True)
    estado = models.CharField(
        max_length=20,
        choices=[
            ('pendiente', 'Pendiente'),
            ('completado', 'Completado'),
            ('cancelado', 'Cancelado')
        ]
    )

    def __str__(self):
        return f"Transacción de {self.producto.nombre} por {self.precio}"

    class Meta:
        verbose_name = "Transacción"
        verbose_name_plural = "Transacciones"
        ordering = ['-fecha']
