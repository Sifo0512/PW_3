from django.db import models
from productos.models import Producto
from usuarios.models import Usuario
# Obtenemos el modelo de usuario personalizado

class Review(models.Model):
    # Campos del modelo
    producto = models.ForeignKey(Producto, on_delete=models.CASCADE, related_name="reviews")
    usuario = models.ForeignKey(Usuario, on_delete=models.CASCADE, related_name="reviews")
    calificacion = models.PositiveSmallIntegerField()  # Valor de 1 a 5
    comentario = models.TextField(blank=True, null=True)  # Comentario opcional
    fecha = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Review de {self.usuario.username} para {self.producto.nombre}"

    class Meta:
        verbose_name = "Reseña"
        verbose_name_plural = "Reseñas"
        ordering = ['-fecha']  # Ordenar por las reseñas más recientes
