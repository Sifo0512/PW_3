from django.urls import path
from . import views

urlpatterns = [
    path('', views.product_list, name='product_list'),
    path('crear/', views.create_product, name='create_product'),
    path('<slug:slug>/', views.product_detail, name='product_detail'),
]