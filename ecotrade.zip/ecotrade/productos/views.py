from django.shortcuts import redirect, get_object_or_404
from django.http import HttpResponse
from django.template import loader
from django.core.paginator import Paginator

from django.shortcuts import render, redirect
from .models import Producto
from .forms import ProductoForm

def create_product(request):
    if request.method == 'POST':
        form = ProductoForm(request.POST, request.FILES)
        if form.is_valid():
            product = form.save(commit=False)
            product.user = request.user
            product.save()
            return redirect('product_list')
    else:
        form = ProductoForm()
    return render(request, 'productos/create.html', {'form': form})

def product_detail(request, slug):
    product = get_object_or_404(Producto, slug=slug)
    return render(request, 'productos/detail.html', {'product': product})

def product_list(request):
    products = Producto.objects.all()
    return render(request, 'productos/list.html', {'products': products})