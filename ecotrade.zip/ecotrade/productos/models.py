from django.db import models
from usuarios.models import Usuario


class Categoria(models.Model):
    name = models.CharField(max_length=100, unique=True)  # Nombre de la categoría
    description = models.TextField(blank=True, null=True)  # Descripción opcional

    def __str__(self):
        return self.name


class Producto(models.Model):
    title = models.CharField(max_length=255)  # Nombre del producto
    description = models.TextField()  # Descripción detallada
    category = models.ForeignKey(Categoria, on_delete=models.SET_NULL, null=True)  # Categoría del producto
    condition = models.CharField(
        max_length=50,
        choices=[('new', 'Nuevo'), ('used', 'Usado')],
        default='used'
    )  
    price = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)  # Precio del producto
    owner = models.ForeignKey(Usuario, on_delete=models.CASCADE)  # Usuario que publica el producto
    location = models.CharField(max_length=255, null=True, blank=True)  # Ubicación del producto
    is_available = models.BooleanField(default=True)  # Si el producto está disponible
    created_at = models.DateTimeField(auto_now_add=True)  # Fecha de creación
    updated_at = models.DateTimeField(auto_now=True)  # Fecha de última actualización

    def __str__(self):
        return self.title

class ProductoImagen(models.Model):
    product = models.ForeignKey(Producto, on_delete=models.CASCADE, related_name='images')  # Producto relacionado
    image = models.ImageField(upload_to='productos/')  # Ruta de almacenamiento
    uploaded_at = models.DateTimeField(auto_now_add=True)  # Fecha de carga

    def __str__(self):
        return f"Image for {self.product.title}"

class Favorito(models.Model):
    user = models.ForeignKey(Usuario, on_delete=models.CASCADE)  # Usuario que marcó el producto
    product = models.ForeignKey(Producto, on_delete=models.CASCADE)  # Producto marcado como favorito
    created_at = models.DateTimeField(auto_now_add=True)  # Fecha en la que se agregó a favoritos

    class Meta:
        unique_together = ('user', 'product')  # Evitar duplicados

    def __str__(self):
        return f"{self.user.username} - {self.product.title}"

class Transacciones(models.Model):
    product = models.ForeignKey(Producto, on_delete=models.CASCADE)  # Producto en transacción
    buyer = models.ForeignKey(Usuario, on_delete=models.CASCADE, related_name='purchases')  # Comprador
    seller = models.ForeignKey(Usuario, on_delete=models.CASCADE, related_name='sales')  # Vendedor
    status = models.CharField(
        max_length=50,
        choices=[
            ('pending', 'Pendiente'),
            ('completed', 'Completada'),
            ('cancelled', 'Cancelada')
        ],
        default='pending'
    )  # Estado de la transacción
    created_at = models.DateTimeField(auto_now_add=True)  # Fecha de creación
    updated_at = models.DateTimeField(auto_now=True)  # Fecha de última actualización

    def __str__(self):
        return f"{self.product.title} ({self.status})"
