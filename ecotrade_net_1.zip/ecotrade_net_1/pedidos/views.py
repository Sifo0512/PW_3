from django.shortcuts import loader, redirect, get_object_or_404
from django.http import HttpResponse
from django.contrib import messages

from productos.models import Productos
from .models import Pedido, EstadoPedido, PedidoProducto

# Pagina para agregar producto a carrito
# Página para agregar producto a carrito
def agregarProducto(request, id):
    # Consultar producto
    producto = get_object_or_404(Productos, id=id)  # Manejo de excepción si no se encuentra el producto

    # Agregar producto a Carrito
    if request.method == "POST":
        cantidad = int(request.POST['cantidad'])
        if cantidad:
            # Intentar obtener el estado "carrito", si no existe lo creamos
            estado = EstadoPedido.objects.filter(estado="carrito").first()

            if not estado:
                # Si no se encuentra el estado, lo creamos
                estado = EstadoPedido.objects.create(estado="carrito")

            pedido = Pedido.objects.filter(ref_estado=estado, ref_usuario=request.user).first()
            if not pedido:
                pedido = Pedido.objects.create(ref_estado=estado, ref_usuario=request.user, valor_pedido=0)

            # Revisar si el pedido ya no tenía este producto agregado
            pedido_producto = PedidoProducto.objects.filter(pedido=pedido, producto=producto).first()

            valor = producto.precio * cantidad

            if not pedido_producto:
                pedido_producto = PedidoProducto(
                    pedido=pedido,
                    producto=producto,
                    cantidad=cantidad,
                    valor=valor
                )
            else:
                pedido_producto.cantidad = cantidad
                pedido_producto.valor = valor

            # Guardar asignación de pedido y producto
            pedido_producto.save()

            messages.success(request, "Producto agregado al carrito")
            return redirect('productosIndex')

    # Consultar datos de producto
    context = {'producto': producto}
    # Obtener el template
    template = loader.get_template("agregarProducto.html")
    return HttpResponse(template.render(context, request))



# Pagina para ver el carrito de compras, corresponde al pedido que está en estado carrito
def carritoCompras(request):
    # Consultar pedido en estado carrito "si existe"
    estado = EstadoPedido.objects.filter(estado="carrito").first()  # Usar .first() para evitar IndexError
    if not estado:
        messages.error(request, "No se pudo encontrar el estado del carrito.")
        return redirect('productosIndex')

    pedido = Pedido.objects.filter(ref_estado=estado, ref_usuario=request.user).first()
    if not pedido:
        context = {"mensaje": "No tienes productos en el carrito."}
        template = loader.get_template("carrito.html")
        return HttpResponse(template.render(context, request))

    # Agregar producto a Carrito
    if request.method == "POST":
        estado_procesado = EstadoPedido.objects.filter(estado="procesado").first()
        if estado_procesado:
            pedido.ref_estado = estado_procesado
            productosPedido = PedidoProducto.objects.filter(pedido=pedido)
            total_pedido = sum(productoPedido.valor for productoPedido in productosPedido)
            pedido.valor_pedido = total_pedido
            pedido.save()
            messages.success(request, "Pedido procesado con éxito")
            return redirect('productosIndex')
        else:
            messages.error(request, "No se pudo cambiar el estado del pedido.")
            return redirect('carritoCompras')

    else:
        productosPedido = PedidoProducto.objects.filter(pedido=pedido)
        total_pedido = sum(productoPedido.valor for productoPedido in productosPedido)
        context = {"pedido": pedido, "productosPedido": productosPedido, "valorPedido": total_pedido}

    # Obtener el template
    template = loader.get_template("carrito.html")
    return HttpResponse(template.render(context, request))


# Controlador para borrar productos del carrito
def borrarProductoCarrito(request, id):
    # Consultar producto
    producto = get_object_or_404(Productos, id=id)  # Manejo de excepción si no se encuentra el producto

    # Consultar pedido carrito
    estado = EstadoPedido.objects.filter(estado="carrito").first()
    if not estado:
        messages.error(request, "No se pudo encontrar el estado del carrito.")
        return redirect('productosIndex')

    pedido = Pedido.objects.filter(ref_estado=estado, ref_usuario=request.user).first()
    if not pedido:
        messages.error(request, "No tienes productos en el carrito.")
        return redirect('productosIndex')

    # Consultar el producto en el carrito
    pedido_producto = PedidoProducto.objects.filter(pedido=pedido, producto=producto).first()
    if pedido_producto:
        pedido_producto.delete()
        messages.warning(request, "Producto eliminado del carrito.")
    else:
        messages.error(request, "El producto no está en el carrito.")

    return redirect('carritoCompras')


# Pagina para ver el historial de pedidos
def pedidos(request):
    # Consultar pedidos del usuario
    pedidos = Pedido.objects.filter(ref_usuario=request.user)

    context = {"pedidos": pedidos}

    # Obtener el template
    template = loader.get_template("pedidos.html")
    return HttpResponse(template.render(context, request))
